$(document).ready(function(){
	alert("hi")
	$(".blackKey").hover(function(){
		alert("hi")
		/*
		$(this).css("background-color","red")
		})*/
	})